class test
{
	String password = "abc123";
}